I'm so happy to finally be able to release our biggest project (Project Luma)!!!!
-it add's 3 amd cpu series and mobos and ram sticks
-custom splash screen
-custom textures
-custom inventory icons
-modded bios and fastboot (in a later version)
==================================================================================
AHE (AMD Hardware Expansion) by Glumboi And Emirpro2244
================================================
Don't upload it anywhere!!
================================================
Updates
0.4 dev
-First ever version of the Mod that is kinda playable
0.5 dev
-Fixed bugs
-added a new cpu series (Athlon II)
0.6 dev
-added more athlon II's
-new inventory icons for the phenom II's
0.7 dev
-added custom watercooling
0.8 dev
-fixed coolers 
-Installer icon added
0.9 dev
-polished everything to make it public ready
0.9.5 dev
-fixed a couple blank sockets on the coolers
0.9.8 dev
-fixed blank sockets on some water blocks
0.9.9 dev
-fixed every bugs that where in the dev beta's
1.0
-first ever public release/reveal
-changed version number ingame
1.1
-Changed the clock from the 7702 to the base clock (2000mhz)
-Fixed some bugs (Epyc 7702 was doubled in the inventory)
1.2
-Added Windows 10 Logos and Buttons (more realistic icons comming soon)
1.3
-Activated Fast boot option in public build (but currently it does nothing)
=============================================================================
Questions
=========
Q:Is this Mod free?
A:sure all my mods r free to use and i dont wanna get donations or something.
I mod Games for fun and not for work/money.
Q:Can i modify the Mod?
A:Yes but dont upload anything without my permission
Q:I found a Bug where can i report it?
A:Either on nexus or in my Discord server/private.
My Discord server:https://discord.gg/37mxP2HX
My Discord ID Glumboi#4563 if this is not working type this instead:#4563
Emir's Discord ID Emirpro2244#7393
Fanicat's Discord ID Der Stecher#4065
Q:I found a Bug and i fixed it can i upload the fixed version?
A:Yea u actually can do that but u must do a post under the mod with the download link.
But after 1 week u need to remove it.
========================================================================================
Creators&Stuff
Glumboi
Emirpro2244
fanicat1337
================================================
We hope you enjoy the mod!